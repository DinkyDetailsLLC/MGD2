//
//  AppDelegate.h
//  SpriteKit
//
//  Created by DANIEL ANNIS on 5/7/14.
//  Copyright (c) 2014 Dinky_Details. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
