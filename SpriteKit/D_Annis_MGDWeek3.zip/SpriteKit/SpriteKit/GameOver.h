//
//  GameOver.h
//  SpriteKit
//
//  Created by DANIEL ANNIS on 5/8/14.
//  Copyright (c) 2014 Dinky_Details. All rights reserved.
//


#import <SpriteKit/SpriteKit.h>

@interface GameOver : SKScene

-(id)initWithSize:(CGSize)size lose: (NSInteger)game_over;

@end